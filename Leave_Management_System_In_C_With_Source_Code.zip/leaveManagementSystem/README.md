# leaveManagementSystem
Employee leave management system using file structures in c++(object oriented) mini-project.
